// Computer Architecture CO2070 - Lab 02
// Design: Register File of Simple Processor
// Author: Kisaru Liyanage

module reg_file_tb;
    
    reg [7:0] WRITEDATA;
    reg [2:0] WRITEREG, READREG1, READREG2;
    reg CLK, RESET, WRITEENABLE; 
    wire [7:0] REGOUT1, REGOUT2;
    
    reg_file myregfile(WRITEDATA, REGOUT1, REGOUT2, WRITEREG, READREG1, READREG2, WRITEENABLE, CLK, RESET);
       
    initial
    begin
        CLK = 1'b1;
        
        // generate files needed to plot the waveform using GTKWave
        $dumpfile("reg_file_wavedata.vcd");
		$dumpvars(0, reg_file_tb);
        
        // assign values with time to input signals to see output 
        RESET = 1'b0;
        WRITEENABLE = 1'b0;
        
        #4  // 4
        RESET = 1'b1;
        READREG1 = 3'd0;
        READREG2 = 3'd4;
        
        #6  // 10
        RESET = 1'b0;
        
        #2  // 12
        WRITEREG = 3'd2;
        WRITEDATA = 8'd95;
        WRITEENABLE = 1'b1;
        
        #7  // 19
        WRITEENABLE = 1'b0;
        
        #1  // 20
        READREG1 = 3'd2;
        
        #7  // 27
        WRITEREG = 3'd1;
        WRITEDATA = 8'd28;
        WRITEENABLE = 1'b1;
        READREG1 = 3'd1;
        
        #8  // 35
        WRITEENABLE = 1'b0;
        
        #8  // 43
        WRITEREG = 3'd4;
        WRITEDATA = 8'd6;
        WRITEENABLE = 1'b1;
        
        #8  // 51
        WRITEDATA = 8'd15;
        WRITEENABLE = 1'b1;
        
        #10 // 61
        WRITEENABLE = 1'b0;
        
        #6  // 67
        WRITEREG = -3'd1;       // two's complement of 1 is -1, so the register is 7
        WRITEDATA = 8'd50;
        WRITEENABLE = 1'b1;
        
        #5  // 72
        WRITEENABLE = 1'b0;
        
        #10 // 82
        $finish;
    end
    
    // clock signal generation
    always
        #4 CLK = ~CLK;
        
    initial
    begin
        $monitor("Time %g, WRITEDATA = %d, REGOUT1 = %d, REGOUT2 = %d", $time, WRITEDATA, REGOUT1, REGOUT2);
    end

endmodule